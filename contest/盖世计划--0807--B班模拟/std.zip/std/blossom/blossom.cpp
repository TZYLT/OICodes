#include<bits/stdc++.h>

#define ll long long

using namespace std;

inline int read(){
	int x=0,f=1;char c=getchar();
	for(;(c<'0'||c>'9');c=getchar()){if(c=='-')f=-1;}
	for(;(c>='0'&&c<='9');c=getchar())x=x*10+(c&15);
	return x*f;
}

const int mod=998244353;
int ksm(int x,int y,int p=mod){
	int ans=1;
	for(int i=y;i;i>>=1,x=1ll*x*x%p)if(i&1)ans=1ll*ans*x%p;
	return ans%p;
}
int inv(int x,int p=mod){return ksm(x,p-2,p)%p;}
mt19937 rnd(time(0));
int randint(int l,int r){return rnd()%(r-l+1)+l;}
void add(int &x,int v){x+=v;if(x>=mod)x-=mod;}
void Mod(int &x){if(x>=mod)x-=mod;}

void Assert(bool c,int L=0){if(!c){cout<<"Assertion Failed at "<<L<<endl;exit(0);}}

template<typename T>
void cmax(T &x,T v){x=max(x,v);}
template<typename T>
void cmin(T &x,T v){x=min(x,v);}

const int N=4e6+5;
int fac[N],ifac[N];
void init(int V){
	fac[0]=1;for(int i=1;i<=V;i++)fac[i]=1ll*fac[i-1]*i%mod;
	ifac[V]=inv(fac[V])%mod;for(int i=V-1;i>=0;i--)ifac[i]=1ll*ifac[i+1]*(i+1)%mod;
}
int C(int x,int y){
	if(x<y)return 0;
	return 1ll*fac[x]*ifac[y]%mod*ifac[x-y]%mod;
}
int iC(int x,int y){
	if(x<y)return 0;
	return 1ll*ifac[x]*fac[y]%mod*fac[x-y]%mod;
}

const int M=1e6+5;
int n,m,a[M],cnt[M];
int getf(int k){return 1ll*C(n+1,k+1)*iC(n,k)%mod;}
int c[M];
void Add(int l,int r,int v){if(l<=r)add(c[l],v),add(c[r+1],mod-v);}
void calc(int p,int q,int k){
	if(p>q)swap(p,q);
	Add(2,p+1,k);Add(q+2,p+q+1,mod-k);
}

vector<int>S;

void solve(){
	S.clear();
	memset(a,0,sizeof(a)),memset(cnt,0,sizeof(cnt)),memset(c,0,sizeof(c));

	n=read(),m=read();
	for(int i=1;i<=m;i++)a[i]=read();a[++m]=n+1;
	for(int i=m;i>=1;i--)a[i]-=a[i-1];
	int ans=0;
	for(int i=1;i<=m;i++)cnt[a[i]]++;
	for(int i=1;i<=n+1;i++)if(cnt[i])S.emplace_back(i);
	for(int x:S)for(int y:S)calc(x,y,1ll*cnt[x]*cnt[y]%mod);
	for(int i=1;i<=m;i++)calc(a[i],a[i],mod-1);
	for(int i=1;i<m;i++)calc(a[i],a[i+1],mod-2),calc(a[i],a[i+1]-1,2);
	for(int i=1;i<=n;i++)add(c[i],c[i-1]);
	for(int i=1;i<=n;i++)add(c[i],c[i-1]);
	int Iv=inv(2);
	for(int i=1;i<=n;i++)c[i]=1ll*c[i]*Iv%mod;
	for(int i=1;i<=m;i++){
		for(int j=2;j<=a[i]-(i==m);j++)add(c[j],a[i]-j+(i!=m));
	}
	
	for(int i=1;i<=n;i++)add(ans,1ll*c[i]*getf(i)%mod);
	cout<<1ll*ans*fac[n]%mod<<endl;
}

signed main(void){
	
	freopen("blossom.in","r",stdin);
	freopen("blossom.out","w",stdout);

	init(N-5);
	int tt=read();while(tt--)solve();

	return 0;
}
