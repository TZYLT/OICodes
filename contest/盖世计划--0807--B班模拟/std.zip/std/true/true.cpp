#include<bits/stdc++.h>

#define ll long long

using namespace std;

inline ll read(){
	ll x=0,f=1;char c=getchar();
	for(;(c<'0'||c>'9');c=getchar()){if(c=='-')f=-1;}
	for(;(c>='0'&&c<='9');c=getchar())x=x*10+(c&15);
	return x*f;
}

const int mod=998244353;
int ksm(int x,int y,int p=mod){
	int ans=1;
	for(int i=y;i;i>>=1,x=1ll*x*x%p)if(i&1)ans=1ll*ans*x%p;
	return ans%p;
}
int inv(int x,int p=mod){return ksm(x,p-2,p)%p;}
mt19937 rnd(time(0));
int randint(int l,int r){return rnd()%(r-l+1)+l;}
void add(int &x,int v){x+=v;if(x>=mod)x-=mod;}
void Mod(int &x){if(x>=mod)x-=mod;}

void cmax(int &x,int v){x=max(x,v);}
void cmin(int &x,int v){x=min(x,v);}

const int D=10;
const int L=19;
const int MS=20005;
const int W=72;

#define i128 __int128

i128 val[MS];
vector<ll>vec[D];
map<i128,int>ID;
i128 U=1;

int idcnt=0;
i128 getnxt(i128 S,int c){
	auto T=((S>>c)|(S<<c));
	for(int i=0;i<=c;i++)if(S&(1<<i))T|=(1<<(c-i));
	T&=U;
	return T;
}
int getans(i128 S){
	for(int i=0;i<D;i++)if(S&(1<<i))return i;
	puts("???");exit(0);
	return 666;
}

#define fi first
#define se second
#define mk make_pair

int nxt[MS][D],ans[MS];
ll f[D][L][MS];
void prework(){
	U<<=W+1;U--;
	queue<pair<int,int> >q;
	++idcnt;ans[1]=0,ID[1]=1,val[1]=1,q.push(mk(1,0));
	while(q.size()){
		auto t=q.front();q.pop();
		int cur=t.fi,num=t.se;
		if(num==L-1)continue;
		for(int c=1;c<=9;c++){
			auto to=getnxt(val[cur],c);
			auto it=ID.find(to);
			if(it!=ID.end()){nxt[cur][c]=(it->se);continue;}
			ID[to]=++idcnt,nxt[cur][c]=idcnt,ans[idcnt]=getans(to),val[idcnt]=to;
			q.push(mk(idcnt,num+1));
		}
	}
	for(int i=1;i<=idcnt;i++)vec[ans[i]].emplace_back(i);

	for(int i=0;i<D;i++){
		for(int t=0;t<=i;t++)for(int j:vec[t])f[i][0][j]=1;
		for(int j=1;j<L;j++)for(int S=1;S<=idcnt;S++){
			f[i][j][S]+=f[i][j-1][S];// + 0
			for(int c=1;c<=9;c++)f[i][j][S]+=f[i][j-1][nxt[S][c]];
		}
	}
}

int lim;
ll calc(ll x){
	if(lim>=10)return x+1;
	x++;vector<int>vc;ll ans=0;
	while(x)vc.emplace_back(x%10),x/=10;
	int u=1;reverse(vc.begin(),vc.end());
	int len=vc.size();ans+=f[lim][len-1][1];
	for(int i=0;i<len;i++){
		int x=vc[i];
		for(int c=(i==0);c<x;c++){
			int v=(c==0?u:nxt[u][c]);
			ans+=f[lim][len-i-1][v];
		}
		u=(x==0?u:nxt[u][x]);
	}
	return ans;
}

signed main(void){

	freopen("true.in","r",stdin);
	freopen("true.out","w",stdout);

	prework();

	int tt=read();
	while(tt--){
		ll l=read(),r=read();lim=read();
		cout<<calc(r)-calc(l-1)<<'\n';
	}

	return 0;
}
