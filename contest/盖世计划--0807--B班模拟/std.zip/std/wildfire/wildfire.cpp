#include<bits/stdc++.h>

#define ll long long
#define int long long

using namespace std;

inline int read(){
	#ifndef ONLINE_JUDGE
		int ccc;cin>>ccc;return ccc;
	#endif
	int x=0,f=1;char c=getchar();
	for(;(c<'0'||c>'9');c=getchar()){if(c=='-')f=-1;}
	for(;(c>='0'&&c<='9');c=getchar())x=x*10+(c&15);
	return x*f;
}

void cmax(int &x,int v){x=max(x,v);}
void cmin(int &x,int v){x=min(x,v);}

const int N=1e6+5;
int head[N],nxt[N],ver[N],tim[N],tot=1;

void adde(int x,int y,int z){
	++tot,nxt[tot]=head[x],head[x]=tot,ver[tot]=y,tim[tot]=z;
	++tot,nxt[tot]=head[y],head[y]=tot,ver[tot]=x,tim[tot]=z;
}

vector<int>C,T;// Circle edges & Tree edges

int fr[N];bool fc,vis[N],inc[N];
void dfs(int u){
	vis[u]=1;
	// cout<<"dfs "<<u<<endl;
	for(int i=head[u];i;i=nxt[i]){
		if((i^1)==fr[u])continue;
		int v=ver[i];
		// cout<<" -> "<<v<<endl;
		if(vis[v]&&(!fc)){
			int cur=u;fc=1;
			while(cur!=v)inc[fr[cur]]=inc[fr[cur]^1]=1,cur=ver[fr[cur]^1];
			inc[i]=inc[i^1]=1;
		}
		else if(!vis[v])fr[v]=i,dfs(v);
	}
}

int n,m,L;
void solve(){
	n=read(),m=read(),L=read();
	for(int i=1;i<=m;i++){
		int x=read(),y=read(),z=read();
		adde(x,y,z);
	}

	dfs(1);
	for(int i=2;i<=tot;i+=2){
		if(inc[i])C.emplace_back(tim[i]);
		else T.emplace_back(tim[i]);
	}

	// cout<<"C = ";for(int x:C)cout<<x<<" ";puts("");
	// cout<<"T = ";for(int x:T)cout<<x<<" ";puts("");
	
	assert(C.size()>=2||C.size()==0);

	sort(C.begin(),C.end()),sort(T.begin(),T.end());

	auto calc=[=](int tar){
		int res=0;
		for(int x:T)if(x<=tar)res+=tar-x;
		if(!C.empty()){
			for(int i=2;i<C.size();i++)if(C[i]<=tar)res+=tar-C[i];
			if(C[0]+C[1]<=tar)res+=tar-C[0]-C[1];
		}
		return res;
	};

	int l=0,r=1e12,ans=0;
	while(l<=r){
		int mid=(l+r)>>1;
		if(calc(mid)<=L)ans=mid,l=mid+1;
		else r=mid-1;
	}

	cout<<ans<<'\n';

	C.clear(),T.clear();
	for(int i=1;i<=n;i++)fr[i]=0,vis[i]=0;
	for(int i=1;i<=tot;i++)inc[i]=head[i]=nxt[i]=ver[i]=tim[i]=0;tot=1,fc=0;
}

signed main(void){

	freopen("wildfire.in","r",stdin);
	freopen("wildfire.out","w",stdout);

	int tid=read(),tt=read();
	while(tt--)solve();

	return 0;
}
