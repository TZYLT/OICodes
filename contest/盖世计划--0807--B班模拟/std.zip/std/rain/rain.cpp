#include<bits/stdc++.h>

#define ll long long

using namespace std;

inline ll read(){
	ll x=0,f=1;char c=getchar();
	for(;(c<'0'||c>'9');c=getchar()){if(c=='-')f=-1;}
	for(;(c>='0'&&c<='9');c=getchar())x=x*10+(c&15);
	return x*f;
}

const int mod=998244353;
int ksm(int x,int y,int p=mod){
	int ans=1;
	for(int i=y;i;i>>=1,x=1ll*x*x%p)if(i&1)ans=1ll*ans*x%p;
	return ans%p;
}
int inv(int x,int p=mod){return ksm(x,p-2,p)%p;}
mt19937 rnd(time(0));
int randint(int l,int r){return rnd()%(r-l+1)+l;}
void add(int &x,int v){x+=v;if(x>=mod)x-=mod;}
void Mod(int &x){if(x>=mod)x-=mod;}

void cmax(int &x,int v){x=max(x,v);}
void cmin(int &x,int v){x=min(x,v);}

const int N=1e5+5;
int a[N],b[N],n,m,C1,C2,as[N],bs[N],cnt[N];ll k;

int calc1(int x){
	int res=0;
	for(int i=0;i<=C1;i++)cnt[i]=0;
	for(int i=0;i<=n;i++){
		if(as[i]>=x)add(res,cnt[as[i]-x]);
		cnt[as[i]]++;
	}
	return res;
}
int calc2(int x){
	int res=0;
	for(int i=0;i<=C2;i++)cnt[i]=0;
	for(int i=0;i<=m;i++){
		if(bs[i]>=x)add(res,cnt[bs[i]-x]);
		cnt[bs[i]]++;
	}
	return res;
}

signed main(void){
	freopen("rain.in","r",stdin);
	freopen("rain.out","w",stdout); 
	n=read(),m=read(),k=read();
	for(int i=1;i<=n;i++)a[i]=read(),C1+=a[i],as[i]=as[i-1]+a[i];
	for(int i=1;i<=m;i++)b[i]=read(),C2+=b[i],bs[i]=bs[i-1]+b[i];

	int ans=0;
	for(int i=1;i<=n;i++)if(k%i==0&&i<=C1&&k/i<=C2)add(ans,1ll*calc1(i)*calc2(k/i)%mod);
	cout<<ans<<endl;

	return 0;
}
