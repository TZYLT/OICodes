#include<cstdio>
#include<cmath>
#include<algorithm>
#define ll long long
using namespace std;
ll a,b,L,tot,p[100001];
ll ans; 
void dfs(ll x,ll y){
	if(tot>=L)return;
	if(!x||y==1){
		ans+=y;
		tot++;
		return;
	}
	for(ll i=1;i<=p[0]&&p[i]<=y;i++){
		if(y%p[i])continue;
		dfs(x-1,p[i]);
		if(tot>=L)return;
	}
}
int main(){
	freopen("trans.in","r",stdin);
	freopen("trans.out","w",stdout); 
	scanf("%lld%lld%lld",&a,&b,&L);
	for(ll i=1;i*i<=a;i++){
		if(a%i==0){
			p[++p[0]]=i;
			if(i*i!=a)p[++p[0]]=a/i;
		}
	}
	sort(p+1,p+1+p[0]);
	dfs(b,a);
	printf("%lld\n",ans);
	return 0;
}
