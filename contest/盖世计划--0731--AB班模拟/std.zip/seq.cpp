//#pragma GCC optimize("Ofast", "unroll-loops")
//#pragma GCC target("sse", "sse2", "sse3", "ssse3", "sse4")

#ifdef __APPLE__

#include <iostream>
#include <cmath>
#include <algorithm>
#include <stdio.h>
#include <cstdint>
#include <cstring>
#include <string>
#include <cstdlib>
#include <vector>
#include <bitset>
#include <map>
#include <queue>
#include <ctime>
#include <stack>
#include <set>
#include <list>
#include <random>
#include <deque>
#include <functional>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <complex>
#include <numeric>
#include <cassert>
#include <array>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <thread>

#else
#include <bits/stdc++.h>
#endif

#define all(a) a.begin(),a.end()
#define len(a) (int)(a.size())
#define mp make_pair
#define pb push_back
#define fir first
#define sec second
#define fi first
#define se second

using namespace std;

typedef pair<int, int> pii;
typedef long long ll;
typedef long double ld;

template<typename T>
bool umin(T &a, T b) {
    if (b < a) {
        a = b;
        return true;
    }
    return false;
}

template<typename T>
bool umax(T &a, T b) {
    if (a < b) {
        a = b;
        return true;
    }
    return false;
}

#if __APPLE__
#define D for (bool _FLAG = true; _FLAG; _FLAG = false)
#define LOG(...) print(#__VA_ARGS__" ::", __VA_ARGS__) << endl

template<class ...Ts>
auto &print(Ts ...ts) { return ((cerr << ts << " "), ...); }

#else
#define D while (false)
#define LOG(...)
#endif

const int max_n = -1, inf = 1000111222;

//mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

struct DSU {
    int n;
    vector<int> p, cnt;

    inline void make_set(int v) {
        p[v] = v;
    }

    DSU(int n) : n(n) {
        p.resize(n);
        cnt.assign(n, 1);
        for (int i = 0; i < n; i++) {
            make_set(i);
        }
    }

    inline int findset(int v) {
        return (p[v] == v ? p[v] : p[v] = findset(p[v]));
    }

    inline bool unionsets(int a, int b) {
        a = findset(a);
        b = findset(b);
        if (a == b) return false;
        if (cnt[b] > cnt[a]) swap(a, b);
        p[b] = a;
        cnt[a] += cnt[b];
        return true;
    }
};

void solve() {
    int n;
    cin >> n;
    DSU dsu((1 << 20));
    vector<int> a(n);
    vector<bool> have((1 << 20));
    for(int i = 0; i < n; i++) {
        cin >> a[i];
        have[a[i]] = true;
    }
    vector<pair<int, int> > bruh;
    for(int i = 1; i < (1 << 20); i++) {
        if(!have[i]) continue;
        int j = ((~i) & ((1 << 20) - 1));
        vector<pair<int, int> > new_bruh;
        bool good = true;
        for(auto& x : bruh) {
            if((x.se & j) == x.se) continue;
            new_bruh.pb({x.fi, x.se});
            if((x.se & j) == j) good = false;
        }
        if(good) new_bruh.pb({i, j});
        bruh.swap(new_bruh);
    }
    for(auto& x : bruh) {
        for(int subm = x.se; subm; subm = (subm - 1) & x.se)
            if(have[subm]) dsu.unionsets(x.fi, subm);
    }
    vector<vector<int> > comps_ind((1 << 20)), comps_val((1 << 20));
    for(int i = 0; i < n; i++) {
        comps_ind[dsu.findset(a[i])].pb(i);
        comps_val[dsu.findset(a[i])].pb(a[i]);
    }
    vector<int> ans(n);
    for(int i = 0; i < (1 << 20); i++) {
        sort(all(comps_ind[i]));
        sort(all(comps_val[i]));
        for(int j = 0; j < len(comps_ind[i]); j++) ans[comps_ind[i][j]] = comps_val[i][j];
    }
    for(auto& x : ans) cout << x << ' ';
    cout << '\n';
}

signed main() {
   freopen("seq.in", "r", stdin);
   freopen("seq.out", "w", stdout);

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int t = 1;

    //cin >> t;

    while (t--) solve();

}

/*
KIVI
*/
