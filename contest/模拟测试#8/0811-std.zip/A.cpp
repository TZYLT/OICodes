#include<bits/stdc++.h>
using namespace std;
int main(){
	int qu;scanf("%d",&qu);
	while(qu--){
		int l,r;scanf("%d%d",&l,&r);
		if(l==r){
			if(l==1)printf("1 1\n");
			else puts("-1");
		}else if((r-l+1)%2==0){
			for(int i=l;i<=r;i+=2)printf("%d %d\n%d %d\n",i,i+1,i+1,i);
		}else{
			if(l%2==0)puts("-1");
			else{
				printf("%d %d\n%d %d\n%d %d\n",l,l+2,l+1,l,l+2,l+1);
				for(int i=l+3;i<=r;i+=2)printf("%d %d\n%d %d\n",i,i+1,i+1,i);
			}
		}
	}
}
