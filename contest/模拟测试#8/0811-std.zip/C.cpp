#include<bits/stdc++.h>
//#include<ext/pb_ds/assoc_container.hpp>
//#include<ext/pb_ds/hash_policy.hpp>
//#include<ext/pb_ds/priority_queue.hpp>
using namespace std;
//using namespace __gnu_pbds;
#define fi first
#define se second
#define fill0(a) memset(a,0,sizeof(a))
#define fill1(a) memset(a,-1,sizeof(a))
#define fillbig(a) memset(a,63,sizeof(a))
#define pb push_back
#define ppb pop_back
#define mp make_pair
#define mt make_tuple
#define SZ(v) ((int)v.size())
#ifdef LOCAL
#define eprintf(...) fprintf(stderr,__VA_ARGS__)
#else
#define eprintf(...) 1064
#endif
template<typename T1,typename T2>void chkmin(T1 &x,T2 y){if(x>y)x=y;}
template<typename T1,typename T2>void chkmax(T1 &x,T2 y){if(x<y)x=y;}
typedef pair<int,int> pii;
typedef long long ll;
typedef unsigned int u32;
typedef unsigned long long u64;
typedef long double ld;
#ifdef FASTIO
#define FILE_SIZE 1<<23
char rbuf[FILE_SIZE],*p1=rbuf,*p2=rbuf,wbuf[FILE_SIZE],*p3=wbuf;
#ifdef LOCAL
inline char getc(){return getchar();}
inline void putc(char c){putchar(c);}
#else
inline char getc(){return p1==p2&&(p2=(p1=rbuf)+fread(rbuf,1,FILE_SIZE,stdin),p1==p2)?-1:*p1++;}
inline void putc(char x){*p3++=x;}
#endif
template<typename T>void read(T &x){
	x=0;char c=getc();T neg=0;
	while(!isdigit(c))neg|=(c=='-'),c=getc();
	while(isdigit(c))x=x*10+(c-'0'),c=getc();
	if(neg)x=-x;
}
template<typename T>void recursive_print(T x){if(!x)return;recursive_print(x/10);putc(x%10^48);}
template<typename T>void print(T x){if(!x)putc('0');if(x<0)putc('-'),x=-x;recursive_print(x);}
template<typename T>void print(T x,char c){print(x);putc(c);}
void readstr(char *s){char c=getc();while(c<=32||c>=127)c=getc();while(c>32&&c<127)s[0]=c,s++,c=getc();(*s)=0;}
void printstr(string s){for(int i=0;i<s.size();i++)putc(s[i]);}
void printstr(char *s){int len=strlen(s);for(int i=0;i<len;i++)putc(s[i]);}
void print_final(){fwrite(wbuf,1,p3-wbuf,stdout);}
#endif
const int MAXN=3e4;
const int MOD=1e9+7;
const int MAXC=3e5;
const int First10[]={1111,1112,1121,1122,1211,1212,1221,1222,2111,2112};
const int Last10[]={2222,2221,2212,2211,2122,2121,2112,2111,1222,1221};
int pw[MAXC+5],one[MAXN+5],two[MAXN+5],one_two[MAXN+5],two_one[MAXN+5],C[11][11];
vector<int>coef[MAXN+5][11][11];
vector<int>conv(vector<int>A,vector<int>B){
	vector<int>res(A.size()+B.size()-1,0);
	for(int i=0;i<A.size();i++)for(int j=0;j<B.size();j++)
		res[i+j]=(res[i+j]+1ll*A[i]*B[j])%MOD;
	return res;
}
char X[MAXN+5];int n,t;
struct dat{
	int a[11];
	dat(){memset(a,0,sizeof(a));}
}dp[MAXN+5][2];
dat upd(dat x,int v){
	dat res;
	for(int i=0;i<=t;i++){//(10x+v)^i
		for(int j=0;j<=i;j++)
			res.a[i]=(res.a[i]+1ll*pw[j]*x.a[j]%MOD*((v==1)?1:(1<<i-j))%MOD*C[i][j])%MOD;
	}
	return res;
}
void add(dat &x,dat y){for(int i=0;i<=t;i++)x.a[i]=(x.a[i]+y.a[i])%MOD;}
int polycalc(dat a,vector<int>&v){
	int res=0;
	for(int i=0;i<=t;i++)res=(res+1ll*v[i]*a.a[i])%MOD;
	return res;
}
int calc(char *s){
	for(int i=0;i<=n;i++)dp[i][0]=dp[i][1]=dat();
	dp[0][1].a[0]=1;
	for(int i=1;i<=n;i++){
		if(s[i]=='1'){
			add(dp[i][0],upd(dp[i-1][0],1));
			add(dp[i][0],upd(dp[i-1][0],2));
			add(dp[i][1],upd(dp[i-1][1],1));
		}else{
			add(dp[i][0],upd(dp[i-1][0],1));
			add(dp[i][0],upd(dp[i-1][1],1));
			add(dp[i][0],upd(dp[i-1][0],2));
			add(dp[i][1],upd(dp[i-1][1],2));
		}
	}
	if(t==1)return(dp[n][0].a[1]+dp[n][1].a[1])%MOD;
	else{
		int res=0;
		static int rk[MAXN+5];
		memset(rk,0,sizeof(rk));
		for(int i=n;i;i--){
			rk[i]=rk[i+1];
			if(s[i]=='2')rk[i]=min(100,rk[i+1]+(1<<min(29,n-i)));
		}
		for(int i=0;i<n;i++){
			int lft=n-i;
			for(int j=1;j<t;j++){
				if((1<<min(10,lft-1))<j||(1<<min(10,lft-1))<t-j)continue;
				res=(res+polycalc(dp[i][0],coef[lft][t][j]))%MOD;
				if(s[i+1]=='2'&&rk[i+2]>=t-j-1)res=(res+polycalc(dp[i][1],coef[lft][t][j]))%MOD;
			}
		}return res;
	}
}
int main(){
	for(int i=(pw[0]=1);i<=MAXC;i++)pw[i]=10ll*pw[i-1]%MOD;
	for(int i=1;i<=MAXN;i++)one[i]=(10ll*one[i-1]+1)%MOD,two[i]=(10ll*two[i-1]+2)%MOD;
	for(int i=1;i<=MAXN;i++)one_two[i]=(pw[i-1]+two[i-1])%MOD,two_one[i]=(2ll*pw[i-1]+one[i-1])%MOD;
	for(int i=1;i<=MAXN;i++){
		for(int t=2;t<=10;t++)for(int j=1;j<t;j++){
			if((1<<min(10,i-1))<j||(1<<min(10,i-1))<t-j)continue;
			vector<int>prd={1};
			for(int k=1;k<=j;k++){
				int X=(0ll+one_two[i]-Last10[0]+Last10[j-k]+MOD)%MOD,Y=pw[i];
				prd=conv(prd,vector<int>{X,Y});
			}
			for(int k=j+1;k<=t;k++){
				int X=(0ll+two_one[i]-First10[0]+First10[k-j-1]+MOD)%MOD,Y=pw[i];
				prd=conv(prd,vector<int>{X,Y});
			}coef[i][t][j]=prd;
		}
	}
	for(int i=0;i<=10;i++){
		C[i][0]=1;
		for(int j=1;j<=i;j++)C[i][j]=(C[i-1][j]+C[i-1][j-1])%MOD;
	}
	int qu;scanf("%d",&qu);
	while(qu--){
		scanf("%s%d",X+1,&t);n=strlen(X+1);
		printf("%d\n",(calc(X)+MOD)%MOD);
	}
	return 0;
}
