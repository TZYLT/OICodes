#include<bits/stdc++.h>
using namespace std;
const int MAXN=2000;
const int MAXK=50;
const int MOD=1e9+7;
int n,m,k,qu,in[MAXN+5],out[MAXN+5];vector<int>g[MAXN+5];
int x[MAXK+5],dp[MAXN+5][MAXN+5],f[MAXK+5];
int main(){
	scanf("%d%d%d",&n,&m,&qu);
	for(int i=1,u,v;i<=m;i++)scanf("%d%d",&u,&v),g[u].push_back(v),in[v]++,out[u]++;
	for(int i=1;i<=n;i++){if(!in[i])g[0].push_back(i);if(!out[i])g[i].push_back(n+1);}
	for(int i=0;i<=n+1;i++){
		dp[i][i]=1;
		for(int j=i;j<=n+1;j++)for(int k:g[j])dp[i][k]=(dp[i][k]+dp[i][j])%MOD;
	}
	while(qu--){
		scanf("%d",&k);for(int i=1;i<=k;i++)scanf("%d",&x[i]);
		x[0]=0;x[k+1]=n+1;memset(f,0,sizeof(f));f[0]=MOD-1;
		for(int i=1;i<=k+1;i++)for(int j=0;j<i;j++)f[i]=(f[i]+1ll*(MOD-f[j])*dp[x[j]][x[i]])%MOD;
		printf("%d\n",f[k+1]);
	}
	return 0;
}
