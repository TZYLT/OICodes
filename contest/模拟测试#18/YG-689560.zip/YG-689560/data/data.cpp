#include<bits/stdc++.h>
using namespace std;
#define p 998244353
#define inv2 499122177
int n,m;
int v[5050],l[5050],r[5050];
int st[20002000];
int main(){
    freopen("data.in","r",stdin);
    freopen("data.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
        scanf("%d%d%d",v+i,l+i,r+i);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            if(i!=j){
                int t=1ll*v[i]*v[j]%p;
                (st[l[i]+l[j]]+=t)%=p;
                (st[r[i]+r[j]+2]+=t)%=p;
                (st[l[i]+r[j]+1]+=p-t)%=p;
                (st[l[j]+r[i]+1]+=p-t)%=p;
            }
    for(int i=1;i<=20000000;i++)
        (st[i]+=st[i-1])%=p;
    for(int i=1;i<=20000000;i++)
        (st[i]+=st[i-1])%=p;
    while(m--){
        int k;
        scanf("%d",&k);
        printf("%lld\n",1ll*st[k]*inv2%p);
    }
}