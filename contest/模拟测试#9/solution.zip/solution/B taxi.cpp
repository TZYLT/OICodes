#include<bits/stdc++.h>
using namespace std;
using ll=long long;
using uint=unsigned int;
using ull=unsigned long long;
#define endl '\n'
#define lb lower_bound
#define ub upper_bound
#define ne nth_element
#define mie min_element
#define mae max_element
#define eb emplace_back
#define ump unordered_map
#define pq priority_queue
#define clz __builtin_clz
#define ctz __builtin_ctz
#define sz(x) (int)x.size()
#define np next_permutation
#define clzl __builtin_clzll
#define ctzl __builtin_ctzll
#define ppc __builtin_popcount
#define all(x) x.begin(),x.end()
#define ppcl __builtin_popcountll
#define fpi(x) freopen(x,"r",stdin)
#define fpo(x) freopen(x,"w",stdout)
#define Time cerr<<"\nTime: "<<clock()
#define uid uniform_int_distribution
#define me(x,y) memset(x,y,sizeof(x))
#define seed chrono::system_clock::now().time_since_epoch().count()
#ifdef Nuj
template<class T> void _dbg(T h){
	string s=typeid(T).name();
	cerr<<" = ";
	bool f=s=="PKc"||s=="Pc"||s=="Ss";
	if(f) cerr<<'"';if(s=="c") cerr<<(char)39;
	cerr<<h;
	if(f) cerr<<'"';if(s=="c") cerr<<(char)39;
}
template<class T> void _dbg(int l,const char *c,T h){
	if(l) cerr<<fixed<<setprecision(10)<<"In Line "<<l<<' ';
	cerr<<c,_dbg(h),cerr<<endl;
}
template<class T,class...H> void _dbg(int l,const char *c,T h,H... a){
	if(l) cerr<<fixed<<setprecision(10)<<"In Line "<<l<<' ';
	int t=0;bool f=0,g=0;
	while(*c^44||f|g|t){
		if(*c==39) f=!f;if(*c==34) g=!g;
		if(!f&!g) t+=(*c==40)-(*c==41)+(*c==91)-(*c==93)+(*c=='{')-(*c=='}');
		cerr<<*c++;
	}
	_dbg(h),cerr<<", ",_dbg(0,++c,a...);
}
#define dbg(...) _dbg(__LINE__,#__VA_ARGS__,__VA_ARGS__)
#else
#define dbg(...) 0
#define assert(...) 0
#endif
#define mod 998244353
#define inf 0x3f3f3f3f
int p[20];
ll dis[20][100005],dp[1<<18][18];
struct node{
	int to;ll len;
	bool operator <(const node &a)const{
		return len>a.len;
	}
};
vector<node> edge[100005];
bool vis[100005];
void dijkstra(int s){
	pq<node> q;
	q.emplace(node{p[s],0});
	dis[s][p[s]]=0;
	me(vis,0);
	while(!q.empty()){
		auto f=q.top();q.pop();
		if(vis[f.to]) continue;
		vis[f.to]=1;
		for(auto v:edge[f.to]) if(dis[s][v.to]>dis[s][f.to]+v.len){
			dis[s][v.to]=dis[s][f.to]+v.len;
			q.emplace(node{v.to,dis[s][v.to]});
		}
	}
}
int main(){
//	fpi("ex_taxi5.in");
//	fpo("ex_taxi5.out");
	#ifndef Nuj
	cin.tie(0)->sync_with_stdio(0);
	#endif
	int n,m,k;cin>>n>>m>>k;
	while(m--){
		int u,v,w;cin>>u>>v>>w;
		edge[u].eb(node{v,w}),edge[v].eb(node{u,w});
	}
	for(int i=0;i<k;i++) cin>>p[i];
	me(dis,0x3f);
	if(!k){
		p[0]=1,dijkstra(0);
		return cout<<dis[0][n],0;
	}
	for(int i=0;i<k;i++) dijkstra(i);
	me(dp,0x3f);
	for(int i=0;i<k;i++) dp[1<<i][i]=dis[i][1];
	for(int i=0;i<1<<k;i++) for(int j=0;j<k;j++) if(i>>j&1) for(int l=0;l<k;l++) if(j^l&&i>>l&1){
		dp[i][j]=min(dp[i][j],dp[i^1<<j][l]+dis[l][p[j]]);
	}
	for(int i=0;i<k;i++) dp[(1<<k)-1][i]+=dis[i][n];
	cout<<*mie(dp[(1<<k)-1],dp[(1<<k)-1]+k);
	return 0;
}
